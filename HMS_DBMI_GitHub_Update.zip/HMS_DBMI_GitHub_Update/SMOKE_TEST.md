# Smoke test · executive-profile.html · 3 November 2026

Run on a local copy of the GitHub Pages folder (the repository at commit e09fd2d plus the files in this package), in Chromium at 1440 px and 390 px.

**Result: pass.** No script errors, no missing files, no sideways scrolling on a phone.

| Check | Result |
|---|---|
| In-page section links (8) | all land on their section |
| Links to the master plan (10 chapters + decision rights module 25) | all open the right chapter |
| Links to the four program pages (overview and specific) | all open the right chapter |
| Working-platform demonstrations (4) | all open; Advancement and Gift & Development land on Command center, RA dashboard on KPI summary, Finance on its start view |
| Interactive infographic | opens |
| Back-links to the profile | from all five plan pages ("Executive profile" in the series bar) and from the infographic (#achievements, #experience, #concept): all resolve |
| Controls on the profile | 36 of 46 clicked (timeline bars, role buttons, DataHub/Advancement tabs, network nodes, chart segments); 10 role dialogs open with content and close with Escape |
| Same test with the plan files currently in the repo (v1) | also passes |

External links (checked separately on 3 November 2026):
- DBMI projects page — loads.
- HMS Faculty Council minutes PDF — loads; dated April 8, 2026 (the file name on the HMS site says 2025).
- LinkedIn — blocks automated checks; open it once by hand.
- `mailto:` and `tel:` links are not opened by the test.
